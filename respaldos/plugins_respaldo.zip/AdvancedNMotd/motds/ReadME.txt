A random motd configuration file will be taken from this folder and applied.
To create new motd create '.yml' file and fill it with motd configuration.
Note that every ".yml" file in this folder must have motd configuration.