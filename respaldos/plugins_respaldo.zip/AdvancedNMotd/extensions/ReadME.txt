Drop AdvancedNMotd '*.jar' extensions in this folder.
AdvancedNMotd will automatically start them on its load.